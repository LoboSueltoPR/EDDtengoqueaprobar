package def;

import java.util.Queue;
import java.util.LinkedList;

public class QueueEjemplo {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Agregar elementos
        queue.add(10);
        queue.add(20);
        queue.add(30);

        System.out.println("Cola inicial: " + queue);

        // Usando remove() (lanza excepción si está vacía)
        System.out.println("\nUsando remove():");
        try {
            while (true) {
                int value = queue.remove();
                System.out.println("Removed: " + value);
            }
        } catch (Exception e) {
            System.out.println("Excepción al usar remove(): " + e);
        }

        // Volvemos a llenar la cola
        queue.add(100);
        queue.add(200);

        // Usando poll() (NO lanza excepción)
        System.out.println("\nUsando poll():");
        Integer value;
        while ((value = queue.poll()) != null) {
            System.out.println("Polled: " + value);
        }

        System.out.println("Queue vacía, poll() devolvió null sin excepción.");
    }
}