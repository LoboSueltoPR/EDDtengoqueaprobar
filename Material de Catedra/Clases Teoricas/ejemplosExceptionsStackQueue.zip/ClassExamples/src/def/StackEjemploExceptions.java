package def;

import java.util.Stack;
import java.util.EmptyStackException;

public class StackEjemploExceptions {
	public static void main(String[] args) {
        // Creamos una pila de enteros
        Stack<Integer> stack = new Stack<>();

        // Ponemos elementos en la pila
        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Imprimimos la pila: " + stack);

        // Sacamos elementos de la pila
        while (!stack.isEmpty()) {
            int value = stack.pop();
            System.out.println("Elemento sacado: " + value);
        }
        try {
        // la próxima linea arroja EmptyStackException
        	//stack.pop();
        	int x = 10/0;
        	System.out.println("Código inalcanzable.");
        }
        catch (EmptyStackException e){
        	System.out.println("Hubo un intento de desapilar de una pila vacia.");
        	System.out.println("Info error: " + e.getMessage());
        }
        finally {
        	System.out.println("Finally");
        }
        System.out.println("Fuera del try-catch");
    }

}
