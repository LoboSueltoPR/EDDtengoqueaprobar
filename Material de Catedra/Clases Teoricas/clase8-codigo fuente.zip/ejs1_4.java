public <E>  boolean ejercicio4(PositionList<E> lan, PositionList<E> lin) {
		if (lan.isEmpty()) return true;
		if (lin.isEmpty()) return false;
		
		Position<E> p2 = lin.first();
		boolean encontre = false;
		while (p2 != null && encontre == false ) {
			encontre = estaAdentro( lan, lin, p2 );
			p2 = p2 == lin.last()? null : lin.next(p2);
		}
		return encontre;
	}

	private <E>	boolean estaAdentro( PositionList<E> chiquita, PositionList<E> grande, Position<E> posgrande ) {
		boolean iguales = true;
		Position<E> p = chiquita.first();
		while ( iguales && p != null) {
			if ( posgrande == null ) iguales = false;
			//asume que no hay nulos en los elementos de chiquita
			else if (p.element().equals(posgrande.element()) == false)
				         iguales = false;
				 else {
				          p = p == chiquita.last() ? null : chiquita.next(p);
				          posgrande = posgrande == grande.last() ? null : grande.next(posgrande);
				}
		}
		return iguales; 
	}
	
	public <E> boolean ejercicio3(PositionList<E> lin, PositionList<E> lan) {
		boolean result = true;
		
		if (lin.size()!=lan.size()) {
			result = false;
		}
		else {
			if (!(lin.isEmpty() && lan.isEmpty())) {
				Iterator<E> itLin = lin.iterator();
				Iterator<E> itLan = lan.iterator();
				E elemLin;
				E elemLan; 
				while (itLin.hasNext() && result) {
					elemLin = itLin.next();
					elemLan = itLan.next();
					if (elemLin==null) {
						//retorno falso si hay un elemento falso en alguna de las listas
						result=false;
					}
					if (! elemLin.equals(elemLan)) {
						System.out.println("No funciona con nulos. DEvuelvo false");
						result = false;
					}
				}
				//No es necesario el iterador consume todos los elementos dentro del while
				//elemLin = itLin.next();
				//elemLan = itLan.next();
				//if (! elemLin.equals(elemLan)) {
				//	result = false;
			}
		}
		return result;
	}
	
	public <E> boolean ejercicio2(E elem, PositionList<E> lin) {
		boolean result = false;
		if (elem== null) {
			System.out.println("No funciona con nulos. DEvuelvo false");
		}
		else {
			for (E e: lin) {
				if (elem.equals(e)) {
					result = true;
					return result;
				}
			}
		}
		return result;
	}
	
	public <E> int ejercicio1(E elem, PositionList<E> lin) {
		int result = 0;
		if (elem== null) {
			System.out.println("No funciona con nulos. DEvuelvo 0");
		}
		else {
			for (E e: lin) {
				if (elem.equals(e)) {
					result = result + 1;
				}
			}
		}
		return result;
	}