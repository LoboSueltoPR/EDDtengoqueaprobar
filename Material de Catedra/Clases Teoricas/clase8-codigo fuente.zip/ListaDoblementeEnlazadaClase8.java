package ar.edu.uns.cs.ed.tdas.tdalista;

import java.util.Iterator;

import ar.edu.uns.cs.ed.tdas.excepciones.*;
import ar.edu.uns.cs.ed.tdas.Position;


public class ListaDoblementeEnlazada<E> implements PositionList<E> {
...

    public ListaDoblementeEnlazada<E> clone(){
		return clonar1();
	}
	
	private ListaDoblementeEnlazada<E> clonar1() {
		ListaDoblementeEnlazada<E> nuevaLista = new ListaDoblementeEnlazada<>();
		for (E elem:this) {
			nuevaLista.addLast(elem);
		}
		return nuevaLista;
	
	}
	
	private ListaDoblementeEnlazada<E> clonar2() {
		ListaDoblementeEnlazada<E> nuevaLista = new ListaDoblementeEnlazada<>();
		Position<E> pos, ultima;
		pos = this.first();
		ultima = this.last();
		while (pos!=null) {
			nuevaLista.addLast(pos.element());
			pos = pos==ultima? null: this.next(pos);
		}
		return nuevaLista;
	
	}
	
	public void med(E e) {
		//no uso las operaciones del TDA PositionList
		DNode<E> pos = this.header.getNext();
		while (pos!= this.trailer) {
			if (pos.element().equals(e)) {
				DNode<E> anterior = pos.getPrev();
				DNode<E> siguiente = pos.getNext();
				anterior.setNext(siguiente);
				siguiente.setPrev(anterior);
				pos.setElement(null);
				cantElems--;
			}	
			pos = pos.getNext();
		}
	}
	
	public void atp(E e) {
		//no uso las operaciones del TDA PositionList
		DNode<E> pos = this.header.getNext();
		while (pos!= this.trailer) {
			if (!pos.element().equals(e)) {
				DNode<E> anterior = pos.getPrev();
				DNode<E> nuevo = new DNode<E>(anterior, pos, e);
				anterior.setNext(nuevo);
				pos.setPrev(nuevo);
				cantElems++;
			}	
			pos = pos.getNext();
		}
	}
    
...
}    